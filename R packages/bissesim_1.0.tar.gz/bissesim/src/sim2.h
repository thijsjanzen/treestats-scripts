//
//  sim2.h
//  test_bissesim
//
//  Created by thijsjanzen on 16/05/2023.
//

#ifndef sim2_h
#define sim2_h

#include <vector>
#include <array>
#include <random>
#include <algorithm>
#include <numeric>

// enum event_type {shift, speciation, extinction, max_num};

using ltab = std::vector< std::array< float, 4> >;

struct bisse_sim2 {
  const std::array<float, 2> m_;
  const std::array<float, 2> l_;
  const std::array<float, 2> q_;
  std::array<float, 2> sr;

  std::vector< std::uniform_real_distribution<float> > event_dist;

  float t;
  float max_time;
  const int max_lin;
  const int source_state_;
  int init_state;


  std::mt19937 rndgen_;
  std::uniform_real_distribution<float> r;

  ltab L;
  std::vector<float> sum_rates;
  float max_rate = 0.0;
  float total_sum_rate;
  std::vector<size_t> traits;
  std::vector<float> ids;

  bisse_sim2(std::array<float, 2> m,
             std::array<float, 2> l,
             std::array<float, 2> q,
             float mt,
             int ml,
             int source_state):
    m_(m), l_(l), q_(q),
    source_state_(source_state),
    max_time(mt),
    max_lin(ml){
    std::random_device rd;
    std::mt19937 rndgen_t(rd());
    rndgen_ = rndgen_t;
    sr[0] = m_[0] + l_[0] + q_[0];
    sr[1] = m_[1] + l_[1] + q_[1];
    r = std::uniform_real_distribution<float>(0.0, 1.0);

    event_dist.resize(2);
    event_dist[0] = std::uniform_real_distribution<float>(0.0, q_[0] + l_[0] + m_[0] );
    event_dist[1] = std::uniform_real_distribution<float>(0.0, q_[1] + l_[1] + m_[1] );
  }

  void run() {
    t = 0.0;
    init_state = source_state_;
    if (init_state < 0) { // randomly draw initial trait
      std::uniform_int_distribution<size_t> d(0, 2);
      init_state = d(rndgen_);
    }

    traits.push_back(init_state);
    traits.push_back(init_state);
    sum_rates.push_back(sr[init_state]);
    sum_rates.push_back(sr[init_state]);
    max_rate = sr[init_state];
    total_sum_rate = sr[init_state] * 2;
    ids.push_back(-1);
    ids.push_back(2);

    L.push_back({0.0, 0, -1, -1});
    L.push_back({0.0, -1, 2, -1});

    while (true) {
      float dt = draw_dt();
      t += dt;
      if (t > max_time)  {
        break;
      }

      size_t picked_indiv = pick_indiv();
      auto event = pick_event(picked_indiv);
      do_event(event, picked_indiv);
      if (traits.size() < 2) break;
    }
  }

  float draw_dt() {
    std::exponential_distribution<float> exp_dist(total_sum_rate);
    return exp_dist(rndgen_);
  }

  size_t pick_indiv() {
    size_t index_chosen_species = 0;
    std::uniform_int_distribution<> d(0, static_cast<int>(sum_rates.size()) - 1);

    float mult = 1.0 / max_rate;
    while (true) {
      index_chosen_species = d(rndgen_);
      float rel_prob = sum_rates[index_chosen_species] * mult;
      if (rel_prob > 0.0) {
        if (rel_prob <= 1.0 - 1e-9) break;

        if (r(rndgen_) < rel_prob) {
          break;
        }
      }
    }
    return index_chosen_species;
  }

  event_type pick_event(const size_t& picked_indiv) {
    auto focal_trait = traits[picked_indiv];
    float local_r = event_dist[focal_trait](rndgen_);
    // ordering of rates is:
    // {shift, speciation, extinction, max_num};
    if (local_r <=  q_[focal_trait]) return shift;
    if (local_r  <= q_[focal_trait] + l_[focal_trait]) return speciation;

    return extinction;
  }

  void do_event(const event_type& event, const size_t& picked_indiv ) {
    switch(event) {
    case speciation:
      do_speciation(picked_indiv);
      break;
    case extinction:
      do_extinction(picked_indiv);
      break;
    case shift:
      do_shift(picked_indiv);
      break;
    default:
      break;
    }
  }

  void update_max_rate(const float& old_trait) {
    // the old max rate has shifted away. We need to find another individual with the same trait
    bool trait_found = false;
    for (const auto& i : traits) {
      if (i == old_trait) {
        trait_found = true;
        break;
      }
    }
    if (!trait_found) { // this was the last individual with that trait
      max_rate = sr[1 - old_trait];
    }
  }

  void do_shift(size_t index) {
    total_sum_rate += sr[1 - traits[index]] - sr[traits[index]];

    traits[index] = 1 - traits[index];
    sum_rates[index] = sr[traits[index]];

    if (sum_rates[index] > max_rate) {
      max_rate = sum_rates[index];
    } else {
      update_max_rate(1 - traits[index]);
    }
  }

  void do_speciation(size_t index) {
    traits.push_back(traits[index]);
    sum_rates.push_back(sum_rates[index]);

    float parent_id = ids[index];
    float daughter_id = parent_id < 0 ? -1.0 * (L.size() + 1.0) : 1.0 * (L.size() + 1.0);

    total_sum_rate += sr[traits[index]];
    ids.push_back(daughter_id);
    L.push_back({t, parent_id, daughter_id, -1.0});
  }

  void do_extinction(size_t index) {
    L[std::abs(ids[index]) - 1][3] = t;
    float old_trait = traits[index];
    total_sum_rate -= sr[old_trait];

    traits[index] = traits.back(); traits.pop_back();
    sum_rates[index] = sum_rates.back(); sum_rates.pop_back();
    ids[index] = ids.back(); ids.pop_back();

    update_max_rate(old_trait);
  }

  ltab extract_ltab() {
    return L;
  }

  std::vector<int> get_traits() {
    std::vector<int> traits_output(traits.size() * 2);
    for (size_t i = 0; i < traits.size(); ++i) {
      auto index = i * 2;
      traits_output[index] = traits[i];
      traits_output[index + 1] = ids[i];
    }
    return traits_output;
  }

  size_t get_initial_state() {
    return init_state;
  }
};




#endif /* sim2_h */
