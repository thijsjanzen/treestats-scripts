
# Version 1.0.5

- Squashed a bug in imbalance_steps that would incorrectly calculate for smaller
trees

# Version 1.0.4

- Corrected wording of variation in branch length statistics to correclty
reflect variance, instead of variation

# Version 1.0.3

First release to CRAN
