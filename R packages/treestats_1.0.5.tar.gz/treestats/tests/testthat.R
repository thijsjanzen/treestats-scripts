library(testthat)
library(treestats) # nolint keep package name non-all-lowercase, due to backwards compatibility

test_check("treestats")
