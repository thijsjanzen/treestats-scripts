

number_of_trees <- 100
crown_age <- 5
min_tips <- 4
max_tips <- 100
num_threads = 5

sim_result <- physim::create_ref_table_tbb_par(num_repl = number_of_trees,
                                               crown_age = crown_age,
                                               min_lin = min_tips,
                                               max_lin = max_tips)

res2 <- physim::generate_trees_tbb(number_of_trees = 100000,
                                   min_tips = 5,
                                   max_tips = 500,
                                   crown_age = 5,
                                   file_name = "/Users/thijsjanzen/test.txt",
                                   num_threads = 8)
