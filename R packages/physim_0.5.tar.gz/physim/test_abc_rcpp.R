sim_func <- function(params) {
  # this is a bit annoying, most C++ functions have the order shuffled:
  sim_tree <- physim::pbd_sim_rcpp(pars = c(params[1], # b1
                                            params[5],   #c1
                                            params[2], #b2
                                            params[3], #mu1
                                            params[4]), #mu2),
                                   age = crown_age)

  if (inherits(sim_tree, "phylo")) {
    return(sim_tree)
  } else {
    return("failure")
  }
}

crown_age <- 30
emp_tree <- sim_func(params = c(0.1, 0.1, 0.0, 0.0, 0.1))

prior_means <- c(10, 10, 100, 100, 1)
obs_lin <- treestats::number_of_lineages(emp_tree)
obs_gamma <- treestats::gamma_statistic(emp_tree)
obs_colless <- treestats::colless(emp_tree)
ca <- treestats::crown_age(emp_tree)

cat(obs_lin, obs_gamma, obs_colless, ca, "\n")

res <- physim::perform_abc_rcpp(num_particles = 100,
                                num_iterations = 5,
                                crown_age = ca,
                                min_lin = obs_lin * 0.5,
                                max_lin = obs_lin * 1.5,
                                lambdas = prior_means,
                                s = 0.05,
                                obs_gamma = obs_gamma,
                                obs_colless = obs_colless,
                                obs_num_lin = obs_lin)


