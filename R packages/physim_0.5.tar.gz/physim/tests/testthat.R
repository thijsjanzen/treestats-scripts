library(testthat)
library(physim) # nolint keep package name non-all-lowercase, due to backwards compatibility

test_check("physim")
