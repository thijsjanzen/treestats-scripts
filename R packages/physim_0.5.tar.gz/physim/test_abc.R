crown_age <- 30

sim_func <- function(params) {
  # this is a bit annoying, most C++ functions have the order shuffled:
  sim_tree <- physim::pbd_sim_rcpp(pars = c(params[1], # b1
                                            params[5],   #c1
                                            params[2], #b2
                                            params[3], #mu1
                                            params[4]), #mu2),
                                   age = crown_age)

  if (inherits(sim_tree, "phylo")) {
    return(sim_tree)
  } else {
    return("failure")
  }
}

emp_tree <- sim_func(params = c(0.1, 0.1, 0.0, 0.0, 0.1))

prior_means <- c(10, 10, 100, 100, 1)

prior_func <- function() {
  return(physim::draw_from_prior_rcpp(prior_means))
}

prior_dens_func <- function(params) {
  return(physim::prior_dens_rcpp(prior_means, params))
}

stat_func <- function(focal_tree) {
  res <- treestats::calc_all_stats(focal_tree)
  # statistics for rquartet and wiener are quite large, and often cause problems:
  index <- which(names(res) == "rquartet")
  res <- res[-index]
  index <- which(names(res) == "wiener")
  res <- res[-index]
  return(res)
}

num_lin <- treestats::number_of_lineages(emp_tree)

res <- physim::abc_smc(ref_tree = emp_tree,
                       min_lin = num_lin * 0.5,
                       max_lin = num_lin * 1.5,
                       statistics = stat_func,
                       simulation_function = sim_func,
                       init_epsilon_value = 10000,
                       prior_generating_function = prior_func,
                       prior_density_function = prior_dens_func,
                       prior_means = prior_means,
                       number_of_particles = 100,
                       sigma = 0.05,
                       stop_rate = 1e-3,
                       num_iterations = 3,
                       num_threads = 8)

to_plot <- c()
for (r in 1:length(res$all_parameters)) {
  focal_iter <- res$all_parameters[[r]]

  focal_iter <- cbind(focal_iter, r)
  to_plot <- rbind(to_plot, focal_iter)
}

colnames(to_plot) <- c("lambda0", "lambda1", "mu0",
                       "mu1", "compl_rate", "repl")
require(tidyverse)
to_plot <- as_tibble(to_plot)

to_plot %>%
  gather(key = "parameter", value = "val", -c(repl)) %>%
  ggplot(aes(x = repl, y = val, group = repl, fill = (repl))) +
  geom_boxplot() +
  scale_y_log10() +
  facet_grid(rows = vars(parameter), scales = "free") +
  theme_classic()

# mean estimates:
to_plot %>%
  filter(repl == max(to_plot$repl)) %>%
  gather(key = "parameter", value = "val", -c(repl)) %>%
  group_by(parameter) %>%
  summarise("mean_val" = mean(val))


