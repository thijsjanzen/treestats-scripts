
/* // everything commented for now, an R improved version makes more sense.
#include <vector>
#include <array>
#include <random>

using ltable = std::vector< std::vector< float >>;

enum species_status {incipient, good};

enum event {speciation, extinction, completion};

struct sim {
  const std::array<float, 2> spec_rate;
  const std::array<float, 2> ext_rate;
  const float compl_rate;

  std::vector< species_status > pop;
  std::vector< float > pop_spec;
  std::vector< float > pop_ext;

  std::array<float, 3> rates;
  float total_rate;

  ltable L;

  std::mt19937_64 rndgen_;

  sim(float lambda0,
      float lambda1,
      float mu0,
      float mu1,
      float com_rate) :
    spec_rate{lambda0, lambda1},
    ext_rate{mu0, mu1},
    compl_rate(com_rate) {
      total_rate = 1e6f;
      std::random_device rd;
      std::mt19937_64 rndgen_t(rd());
      rndgen_ = rndgen_t;
    }

  void run() {
    float t = 0.0;
    L.push_back({0.0, 0, -1, -1});
    L.push_back({0.0, -1, 2, -1});

    pop.push_back(good);
    pop.push_back(good);

    while (true) {
      update_rates();
      float dt = draw_dt();
      t += dt;
      auto event = draw_event();
      apply_event(event);
    }
  }

  void update_rates() {
    rates[speciation] = std::accumulate(pop_spec.begin(), pop_spec.end(), 0.0);
    rates[extinction] = std::accumulate(pop_ext.begin(), pop_ext.end(), 0.0);
    rates[completion] = pop.size() * compl_rate;
    total_rate = rates[speciation] + rates[extinction] + rates[completion];
  }

  float draw_dt() {
    std::exponential_distribution<float> exp_dist(total_rate);
    return exp_dist(rndgen_);
  }

  event draw_event() {
    std::discrete_distribution<> d(rates.begin(), rates.end());
    return static_cast<event>(d(rndgen_));
  }

  void apply_event(const event& e) {
    if (e == completion) {
      do_completion();
    }
    if (e == speciation) {
      do_speciation();
    }
    if (e == extinction) {
      do_extinction();
    }
  }





};
*/
