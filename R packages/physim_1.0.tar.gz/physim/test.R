lambda0 <- 1
mu0 <- 0
lambda1 <- 0
mu1 <- 0.0
trans_rate <- 1

max_t <- 5

for (r in 1:1000) {
  cat(r, "\n")
  focal_tree2 <- physim::sim_pbd(lambda0 = lambda0,
                                  mu0 = mu0,
                                  lambda1 = lambda1,
                                  mu1 = mu1,
                                  completion_rate = trans_rate,
                                  max_t = max_t)

}